# 🛒 E-commerce MERN Stack Website

## 🧑‍💻 Team Members

| Name      | Role                        |
|-----------|-----------------------------|
| Chin      | Team Leader, Backend Dev    |
| Member A  | Frontend Dev (React)        |
| Member B  | UI/UX Designer (Figma)      |
| Member C  | DB & API Integration        |
| Member D  | Testing & Deployment        |

---

## 🚀 Tech Stack

- **Frontend**: React.js, Tailwind CSS
- **Backend**: Node.js, Express.js
- **Database**: MongoDB + Mongoose
- **Tools**: Figma, Postman, GitHub, Notion

---

## 🔧 Folder Structure

client/       --> React Frontend  
server/       --> Node + Express Backend  

---

## 📌 Features

- 🛍️ Product listing
- 🧾 Cart & checkout
- 🔐 User authentication
- 🧾 Order history
- 💬 Responsive UI

---

## 🛠️ Setup Instructions

### Backend

```bash
cd server
npm install
npm start
```

### Frontend

```bash
cd client
npm install
npm start
```

---

## ✅ Deployment

- Frontend: [Vercel/Netlify Link]
- Backend: [Render/Heroku Link]

---

## 📅 Deadlines

- UI Design: July 2  
- Backend APIs: July 3  
- Frontend Integration: July 4  
- Testing & Deployment: July 5  
